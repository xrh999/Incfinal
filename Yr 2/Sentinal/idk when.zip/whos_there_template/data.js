const fs = require('fs')

function readUserData() {
  // YOUR CODE HERE.
  // Read and parse the store.json file, and return the array inside.
  const data = fs.readFileSync('./store.json', 'utf-8')
  const parsedData = JSON.parse(data)
  return parsedData
}

function updateUserData(newuser, newpassword){
  const newUser = {
    username: newuser,
    password: newpassword
  }
  const userData = readUserData()
  JSON.parse(fs.readFileSync("store.json"))
  const newUserData = userData.concat(newUser)
  fs.writeFileSync("store.json",JSON.stringify(newUserData))
}

module.exports = { readUserData, updateUserData }